package queue.adt;

public interface HashTableSet<T> extends Set<T>, HashTableStats {

}
